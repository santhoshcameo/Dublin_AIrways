
package com.airline.cloud;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sound.midi.Synthesizer;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClients;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PrintFood extends HttpServlet {

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter out = resp.getWriter();

		System.out.println(" Inside pritn food do post");
		// handlin ther user authentication from mymql tables
		Connection c1 = null;
		Statement st = null;
		ResultSet rs1;
		String q = "";
		HttpSession session = req.getSession(true);
		String name = (String) session.getAttribute("ticketUser");
		// System.out.println("%%%%%%%%%%%%%%% "+name);

		try {

			// Create an instance of HttpClient.
			HttpClient httpClient = HttpClients.createDefault();

			// Create a method instance.
			HttpGet get = new HttpGet(
					"https://guarded-reaches-19746.herokuapp.com/api/v1/booktickets?identify=" + name);
			get.addHeader("content-type", "application/json");
			// String authHeader = "Basic" + new String(pr);
			get.setHeader("AUTHORIZATION", "Token token=\"BronVuBedTuMsdxRDpQ9Qwtt\"");

			HttpResponse response = httpClient.execute(get);

			int internResponseStatus = response.getStatusLine().getStatusCode();
			StringBuffer result = new StringBuffer();
			if (200 == internResponseStatus) {

				System.out.println("internResponseStatus  " + internResponseStatus);
				BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

				String line = "";
				while ((line = rd.readLine()) != null) {
					// System.out.println("result.line "+line);
					result.append(line);
				}

				System.out.println("result.toString()" + result);
				JSONArray array = new JSONArray(result.toString());
				// int size = array.length() - 1;

				JSONObject jsonObj = array.getJSONObject(array.length() - 1);
				System.out.println(jsonObj.getString("id"));
				System.out.println(jsonObj.getString("name"));
				System.out.println(jsonObj.getString("age"));
				System.out.println(jsonObj.getString("aticket"));
				System.out.println(jsonObj.getString("cticket"));
				System.out.println(jsonObj.getString("tdate"));
				System.out.println(jsonObj.getString("hour"));
				System.out.println(jsonObj.getString("from"));
				System.out.println(jsonObj.getString("to"));
				// System.out.println(jsonObj.getString("proof"));
				System.out.println(jsonObj.getString("cost"));
				System.out.println(jsonObj.getString("tclass"));
				System.out.println(jsonObj.getString("treturn"));

				session.setAttribute("id", jsonObj.getString("id"));
				session.setAttribute("name", jsonObj.getString("name"));
				session.setAttribute("age", jsonObj.getString("age"));
				session.setAttribute("aticket", jsonObj.getString("aticket"));
				session.setAttribute("cticket", jsonObj.getString("cticket"));
				session.setAttribute("tdate", jsonObj.getString("tdate"));
			//	session.setAttribute("hour", jsonObj.getString("hour"));
				session.setAttribute("hour", "12:30");
				session.setAttribute("from", jsonObj.getString("from"));
				session.setAttribute("to", jsonObj.getString("to"));
				session.setAttribute("cost", jsonObj.getString("cost"));
				session.setAttribute("tclass", jsonObj.getString("tclass"));
				session.setAttribute("treturn", jsonObj.getString("treturn"));
				

				String url = "/Print.jsp";
				RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
				dispatcher.forward(req, resp);

			} else {
				out.println("Invalid Login<br>");
				out.println("<a href='Login.jsp'>Sorry, We are experiencing some server issues</a>");
			}

			out.println("<html>");
			out.println("<head>");
			out.println("<link rel='stylesheet' href='style1.css'>");
			// out.println("Welcome, "+lgnm1+"<br>");
			req.getRequestDispatcher("Home.jsp").forward(req, resp);
			out.println("</body>");
			out.println("</body>");

		} catch (Exception e) {
			e.printStackTrace();

		}

	}
}
