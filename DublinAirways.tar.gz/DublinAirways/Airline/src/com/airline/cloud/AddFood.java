
package com.airline.cloud;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.util.Random;

public class AddFood extends HttpServlet {
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		Random rand = new Random();

		long foodVal = (long) (rand.nextDouble() * 10000000000L);
		PrintWriter out = res.getWriter();

		Connection c1 = null;
		Statement st = null;
		ResultSet rs;
		String q = "";
// class that handles the API requests  from webpage
		try {
			String foodtype = req.getParameter("foodtype");
			String dish = req.getParameter("dish");
			String size = req.getParameter("size");
			String quantity = req.getParameter("quantity");
			String date = req.getParameter("date");
			String time = req.getParameter("time");
			String lgnm = req.getParameter("lgnm");

			Class.forName("com.mysql.jdbc.Driver").newInstance();
			//c1 = DriverManager.getConnection("jdbc:mysql://aa18j46yfah0cf0.cbgom6ntwqej.eu-west-1.rds.amazonaws.com:3306/cloud", "root", "myfinalapi");
			
			c1 = DriverManager.getConnection("jdbc:mysql://aa18j46yfah0cf0.cbgom6ntwqej.eu-west-1.rds.amazonaws.com:3306/cloud", "root", "myfinalapi");
			
			out.println("Connection Succesful<br>");

			st = c1.createStatement();
			q = "insert into userandfoodid (lname,food_id) values('" + lgnm + "','" + foodVal + "')";
			st.executeUpdate(q);
			
			System.out.println(" Inserted user login and foodname");
			

			if (null != foodtype && null != dish && null != size && null != quantity && null != date && null != time
					&& !foodtype.isEmpty() && !dish.isEmpty() && !size.isEmpty() && !quantity.isEmpty()
					&& !date.isEmpty() && !time.isEmpty()) {
				//String requestUrl = "http://myfinalapi-env.eu-west-1.elasticbeanstalk.com/employee/";
				String requestUrl = "http://myfinalapi-env.eu-west-1.elasticbeanstalk.com/employee/";
				// String payload =
				// "{\"foodId\":\"40000\",\"foodType\":\"Veg\",\"foodDish\":\"Sandwich\",\"foodSize\":\"Small\",\"foodQuantity\":\"100\",\"foodDate\":\"10-10-10\",\"foodTime\":\"10\"}";
				String payloadNew = "{\"foodId\":\"" + foodVal + "\",\"foodType\":\"" + foodtype + "\",\"foodDish\":\""
						+ dish + "\",\"foodSize\":\"" + size + "\",\"foodQuantity\":\"" + quantity
						+ "\",\"foodDate\":\"" + date + "\",\"foodTime\":\"" + time + "\"}";
				// String Build= "{\"foodId\":\"+"foodVal+ ";

				System.out.println(" before send post in air $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ ");
				
				String JsonVal = sendPostRequest(requestUrl, payloadNew);
				System.out.println(" after send post in air $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ ");

				// String webResponse = RestHttpRequestCall.callWeb(foodVal,
				// foodtype, dish, size, quantity, date, time);

				// if ( webResponse.isEmpty())

				//req.getRequestDispatcher("Print.jsp").forward(req, res);
				req.getRequestDispatcher("BookingCart.jsp").forward(req, res);
			}

			else {
				out.println("Invalid Insertion<br>");
				out.println("<a href='AddFoodToCart.jsp'>Please Fill the Details Again</a>");
			}
		} catch (Exception e) {
			e.printStackTrace();
			req.getRequestDispatcher("BookingCart.jsp").forward(req, res);
		}

		// st.close();
		// c1.close();

	}

	private String sendPostRequest(String requestUrl, String payload) {
		// TODO Auto-generated method stub

		// TODO Auto-generated method stub
		StringBuffer jsonString = new StringBuffer();
		try {
			URL url = new URL(requestUrl);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			System.out.println(" ibside send post $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ ");
			connection.setDoInput(true);
			connection.setDoOutput(true);
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Accept", "application/json");
			connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
			OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
			writer.write(payload);
			writer.close();
			BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));

			String line;
			while ((line = br.readLine()) != null) {
				jsonString.append(line);
			}
			br.close();
			connection.disconnect();
		} catch (Exception e) {
			//req.getRequestDispatcher("Print.jsp").forward(req, res);
			//throw new RuntimeException(e.getMessage());
		}
		System.out.println(jsonString.toString());
		return jsonString.toString();

	}
}
