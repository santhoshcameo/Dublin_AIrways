
package com.airline.cloud;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.servlet.*;
import javax.servlet.http.*;

import com.mysql.jdbc.StringUtils;

import java.sql.*;
import java.util.Random;

public class UpdateFood extends HttpServlet {
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		// Random rand = new Random();

		// long foodVal = (long) (rand.nextDouble() * 10000000000L);
		PrintWriter out = res.getWriter();

		String action = req.getParameter("button");
		
		if (null !=action && !action.isEmpty()){
			
			out.println("Invalid Insertion<br>");
			out.println("<a href='AddFoodToCart.jsp'>Please Fill the Details Again</a>");
			
		}

		//  methode to handle the API update and delete operation
		
		if (action.equalsIgnoreCase("Update")) {

			System.out.println(" INSODE UPDATE FOOD" + action);

			Connection c1 = null;
			Statement st = null;
			ResultSet rs;
			String q = "";

			try {
				String foodVal = req.getParameter("userbookid");
				String foodtype = req.getParameter("foodtype");
				String dish = req.getParameter("dish");
				String size = req.getParameter("size");
				String quantity = req.getParameter("quantity");
				String date = req.getParameter("date");
				String time = req.getParameter("time");

				if (null != foodtype && null != dish && null != size && null != quantity && null != date && null != time
						&& !foodtype.isEmpty() && !dish.isEmpty() && !size.isEmpty() && !quantity.isEmpty()
						&& !date.isEmpty() && !time.isEmpty()) {
					
					//String requestUrl = "http://localhost:8080/SpringExamples/employee/" + foodVal;
					
					String requestUrl = "http://myfinalapi-env.eu-west-1.elasticbeanstalk.com/employee/" + foodVal;

					// String payload =
					// "{\"foodId\":\"40000\",\"foodType\":\"Veg\",\"foodDish\":\"Sandwich\",\"foodSize\":\"Small\",\"foodQuantity\":\"100\",\"foodDate\":\"10-10-10\",\"foodTime\":\"10\"}";
					String payloadNew = "{\"foodId\":\"" + foodVal + "\",\"foodType\":\"" + foodtype
							+ "\",\"foodDish\":\"" + dish + "\",\"foodSize\":\"" + size + "\",\"foodQuantity\":\""
							+ quantity + "\",\"foodDate\":\"" + date + "\",\"foodTime\":\"" + time + "\"}";
					// String Build= "{\"foodId\":\"+"foodVal+ ";

					String JsonVal = sendPostRequest(requestUrl, payloadNew);
					System.out.println("@@ " + JsonVal);

					// String webResponse = RestHttpRequestCall.callWeb(foodVal,
					// foodtype, dish, size, quantity, date, time);

					// if ( webResponse.isEmpty())

					req.getRequestDispatcher("Home.jsp").forward(req, res);
				}

				else {
					out.println("Invalid Insertion<br>");
					out.println("<a href='AddFoodToCart.jsp'>Please Fill the Details Again</a>");
				}
			} catch (Exception e) {
				e.printStackTrace();
				out.println("Connection Fail..");
			}
		}

		if (action.equalsIgnoreCase("Delete")) {

			Connection c1 = null;
			Statement st = null;
			ResultSet rs;
			String q = "";

			try {
				String foodVal = req.getParameter("userbookid");
				String foodtype = req.getParameter("foodtype");
				String dish = req.getParameter("dish");
				String size = req.getParameter("size");
				String quantity = req.getParameter("quantity");
				String date = req.getParameter("date");
				String time = req.getParameter("time");

				if (null != foodtype && null != dish && null != size && null != quantity && null != date && null != time
						&& !foodtype.isEmpty() && !dish.isEmpty() && !size.isEmpty() && !quantity.isEmpty()
						&& !date.isEmpty() && !time.isEmpty()) {
				//	String requestUrl = "http://localhost:8080/SpringExamples/employee/delete/" + foodVal;
					String requestUrl = "http://myfinalapi-env.eu-west-1.elasticbeanstalk.com/employee/delete/" + foodVal;

					String payloadNew = "{\"foodId\":\"" + foodVal + "\",\"foodType\":\"" + foodtype
							+ "\",\"foodDish\":\"" + dish + "\",\"foodSize\":\"" + size + "\",\"foodQuantity\":\""
							+ quantity + "\",\"foodDate\":\"" + date + "\",\"foodTime\":\"" + time + "\"}";

					String JsonVal = sendDeleteRequest(requestUrl, payloadNew);
					

					req.getRequestDispatcher("Home.jsp").forward(req, res);
				}

				else {
					out.println("Invalid Insertion<br>");
					out.println("<a href='AddFoodToCart.jsp'>Please Fill the Details Again</a>");
				}
			} catch (Exception e) {
				e.printStackTrace();
				out.println("Connection Fail..");
			}

		}

		// st.close();
		// c1.close();

	}

	private String sendDeleteRequest(String requestUrl, String payload) {
		// TODO Auto-generated method stub

		// TODO Auto-generated method stub
		StringBuffer jsonString = new StringBuffer();
		try {
			URL url = new URL(requestUrl);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();

			connection.setDoInput(true);
			connection.setDoOutput(true);
			connection.setRequestMethod("DELETE");
			connection.setRequestProperty("Accept", "application/json");
			connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
			OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
			writer.write(payload);
			writer.close();
			BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));

			String line;
			while ((line = br.readLine()) != null) {
				jsonString.append(line);
			}
			br.close();
			connection.disconnect();
		} catch (Exception e) {
			//throw new RuntimeException(e.getMessage());
		}
		System.out.println(jsonString.toString());
		return jsonString.toString();

	}

	private String sendPostRequest(String requestUrl, String payload) {
		// TODO Auto-generated method stub

		// TODO Auto-generated method stub
		StringBuffer jsonString = new StringBuffer();
		try {
			URL url = new URL(requestUrl);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();

			connection.setDoInput(true);
			connection.setDoOutput(true);
			connection.setRequestMethod("PUT");
			connection.setRequestProperty("Accept", "application/json");
			connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
			OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
			writer.write(payload);
			writer.close();
			BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));

			String line;
			while ((line = br.readLine()) != null) {
				jsonString.append(line);
			}
			br.close();
			connection.disconnect();
		} catch (Exception e) {
			//throw new RuntimeException(e.getMessage());
		}
		System.out.println(jsonString.toString());
		return jsonString.toString();

	}
}
