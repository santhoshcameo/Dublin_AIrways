
package com.airline.cloud;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicHeader;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.protocol.HTTP;
import org.json.simple.JSONObject;

import com.mysql.jdbc.StringUtils;

import java.sql.*;

public class Reserve extends HttpServlet {
	String pr = "BronVuBedTuMsdxRDpQ9Qwtt";

	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		System.out.println("INSIDE RESERVE ££££££££££££££££££££££££££££");
		try {
			Connection c1 = null;
			Statement st = null;
			ResultSet rs1;
			String q = "";

			String lgnm = req.getParameter("lgnm");
			String age = req.getParameter("age");
			String adult = req.getParameter("adult");
			String child = req.getParameter("child");
			String date = req.getParameter("date");
			String time = req.getParameter("time");
			String source = req.getParameter("source");
			String dest = req.getParameter("dest");
			String ppsn = lgnm;
			String total = req.getParameter("total");
			String classc = req.getParameter("classc");
			String way = req.getParameter("way");

			String idcol = "0";

			// session.setAttribute("SES_NAME",lgnm);

			// class to handle food reservations
			// System.out.println(adult);
			// System.out.println(child);
			// System.out.println("classc"+classc);
			// System.out.println("way"+way);
			// System.out.println("total"+total);

			if (null != lgnm && null != source && null != dest && null != date && null != time) {

				if (!lgnm.isEmpty() && !source.isEmpty() && !dest.isEmpty() && !date.isEmpty() && !time.isEmpty()) {

					System.out.println("fields are not null &&&&&&&&&&&&&&&&&&&&&");
					String pr = "BronVuBedTuMsdxRDpQ9Qwtt";
					Class.forName("com.mysql.jdbc.Driver").newInstance();
					// out.println("in reserve class");
					// c1 =
					// DriverManager.getConnection("jdbc:mysql://localhost:3306/cloud",
					// "root", "root");
					// out.println("Connection Succesful<br>");

					// st = c1.createStatement();
					// q = "insert into pass values('" + "1','santhoh" + "','" +
					// "ca" + "','" + "da" + "','" + "112122" + "','" + "12" +
					// "')";
					// q = "insert into pass values('1','"+"lgnm "+ "','" +
					// source +
					// "','" + dest + "','" + date + "','" + time + "')";

					// q = "insert into pass values('" + lgnm + "','" + source +
					// "','" + dest + "','" + date + "','" + time + "')";
					// q = "insert into pass values('" + idcol + "','" + lgnm +
					// "','" + source + "','" + dest + "','"
					// + date + "','" + time + "')";
					// out.println(q);

					// int n = st.executeUpdate(q);
					// out.println("$$$$$ :" + n);
					// System.out.println("£££££££££££"+n);
					// out.print("Name : " + lgnm + "<br>");

					// sendJson(lgnm,age,adult,child,date,time,source,dest,ppsn,total,classc,way);
					JSONObject json = new JSONObject();
					json.put("name", lgnm);
					json.put("age", age);
					json.put("aticket", adult);
					json.put("cticket", child);
					json.put("tdate", date);
					json.put("thour", time);
					json.put("from", source);
					json.put("to", dest);
					json.put("proof", ppsn);
					json.put("cost", total);
					json.put("tclass", classc);
					json.put("treturn", way);

					CloseableHttpClient httpClient = HttpClientBuilder.create().build();

					try {
						HttpPost request = new HttpPost(
								"https://guarded-reaches-19746.herokuapp.com/api/v1/booktickets");
						String fJson = "{" + "\"bookticket\":" + json.toString() + "}";
						// StringEntity params = new StringEntity(json.toStrin
						StringEntity params = new StringEntity(fJson.toString());
						// String
						// fJson="{"+"\"bookticket\":"+json.toString()+"}";
						System.out.println(fJson);
						request.addHeader("content-type", "application/json");
						// String authHeader = "Basic" + new String(pr);
						request.setHeader("AUTHORIZATION", "Token token=\"BronVuBedTuMsdxRDpQ9Qwtt\"");
						request.setEntity(params);
						httpClient.execute(request);
						// handle response here...
					} catch (Exception ex) {
						// handle exception here
						ex.printStackTrace();

					} finally {
						httpClient.close();
					}

					req.getRequestDispatcher("FoodReservation.jsp").forward(req, res);

				} else {
					out.println("Fields are blank");
					out.println("<a href='ticketreservation.jsp'>Fields are blank ,Please Try Again</a>");
				}

			} else {
				out.println("Invalid Insertion<br>");
				out.println("<a href='ticketreservation.jsp'>Please Try Again</a>");
			}

		} catch (Exception e) {
			out.println("Connection Fail..");
		}
	}

	/*
	 * private void sendJson(String lgnm, String age, String adult, String
	 * child, String date, String time, String source, String dest, String ppsn,
	 * String total, String classc, String way) { // TODO Auto-generated method
	 * stub //PrintWriter out = res.getWriter(); HttpClient client = new
	 * DefaultHttpClient();
	 * HttpConnectionParams.setConnectionTimeout(client.getParams(), 1000);
	 * //Timeout Limit HttpResponse response; JSONObject json = new
	 * JSONObject();
	 * 
	 * try { HttpPost post = new
	 * HttpPost("https://guarded-reaches-19746.herokuapp.com/api/v1/booktickets"
	 * ); json.put("name", lgnm); json.put("age", age); json.put("aticket",
	 * adult); json.put("cticket", child); json.put("tdate", date);
	 * json.put("thour", time); json.put("from", source); json.put("to", dest);
	 * json.put("proof", ppsn); json.put("cost", total); json.put("tclass",
	 * classc); json.put("treturn", way);
	 * 
	 * 
	 * 
	 * 
	 * StringEntity se = new StringEntity(json.toString());
	 * se.setContentType(new BasicHeader(HTTP.CONTENT_TYPE,
	 * "application/json")); se.setContentType(new BasicHeader("Authorization",
	 * pr)); post.setEntity(se); response = client.execute(post);
	 * 
	 * Checking response if (response != null) {
	 * System.out.println(" RESPONSE **************"+response); InputStream in =
	 * response.getEntity().getContent(); //Get the data in the entity }
	 * 
	 * } catch (Exception e) { e.printStackTrace();
	 * //out.println("Cannot Estabilish Connection"); }
	 * 
	 * 
	 * }
	 */
}
