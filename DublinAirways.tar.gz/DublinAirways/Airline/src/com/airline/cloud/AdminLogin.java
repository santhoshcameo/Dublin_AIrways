
package com.airline.cloud;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

public class AdminLogin extends HttpServlet {

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter out = resp.getWriter();

		
		// handlin ther user authentication from mymql tables
		Connection c1 = null;
		Statement st = null;
		ResultSet rs1;
		String q = "";

		try {

			String lgnm1 = req.getParameter("lgnm");
			String ps1 = req.getParameter("pwd");

			if (null != lgnm1 && null != ps1 && !lgnm1.isEmpty() && !ps1.isEmpty()) {

				Class.forName("com.mysql.jdbc.Driver").newInstance();
				c1 = DriverManager.getConnection("jdbc:mysql://aa18j46yfah0cf0.cbgom6ntwqej.eu-west-1.rds.amazonaws.com:3306/cloud", "root", "myfinalapi");

				st = c1.createStatement();
				q = "select * from user where lname='" + lgnm1 + "' and password='" + ps1 + "'";
				rs1 = st.executeQuery(q);
				if (rs1.next()) {
					out.println("<html>");
					out.println("<head>");
					out.println("<link rel='stylesheet' href='style1.css'>");
					// out.println("Welcome, "+lgnm1+"<br>");
					req.getRequestDispatcher("AdminHome.jsp").forward(req, resp);
					out.println("</body>");
					out.println("</body>");
				} else {
					out.println("Invalid Login<br>");
					out.println("<a href='AdminLogin.jsp'>Try Again</a>");
				}
			} else {
				out.println("<a href='Login.jsp'>Please enter username and password </a>");
			}

		} catch (Exception e) {

		}

	}
}
