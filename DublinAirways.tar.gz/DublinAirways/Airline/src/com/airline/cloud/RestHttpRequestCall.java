package com.airline.cloud;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.simple.JSONObject;



public class RestHttpRequestCall {

	public static String callWeb(long foodVal, String foodtype, String dish, String size, String quantity, String date,
			String time) {

		// TODO Auto-generated method stub

		// String message;
		JSONObject json = new JSONObject();

		json.put("foodId", foodVal);
		json.put("foodType", foodtype);
		json.put("foodDish", dish);
		json.put("foodSize", size);
		json.put("foodQuantity", quantity);
		json.put("foodDate", date);
		json.put("foodTime", time);

		
		
	//	System.out.println();
		// message =
//		String payload = json.toString();
		// escape the double quotes in json string
		
		
		
	 String payload =
	 "{\"foodId\":\"50000\",\"foodType\":\"Veg\",\"foodDish\":\"Sandwich\",\"foodSize\":\"Small\",\"foodQuantity\":\"100\",\"foodDate\":\"10-10-10\",\"foodTime\":\"10\"}";
		// String requestUrl = "http://localhost:8080/SpringExamples/employee/";
		// String requestUrl =
		// "http://localhost:8080/SpringExamples/employee/500";
		// String requestUrl =
		// "http://localhost:8080/SpringExamples/employee/delete/2000";

		//String requestUrl = "http://localhost:8080/SpringExamples/employee/";
	 String requestUrl = "http://myfinalapi-env.eu-west-1.elasticbeanstalk.com/employee/";

		String res = sendPostRequest(requestUrl, payload);
		//System.out.println(res);
		return res;

	}

	private static String sendPostRequest(String requestUrl, String payload) {
		// TODO Auto-generated method stub
		StringBuffer jsonString = new StringBuffer();
		try {
			URL url = new URL(requestUrl);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();

			connection.setDoInput(true);
			connection.setDoOutput(true);
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Accept", "application/json");
			connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
			OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
			writer.write(payload);
			writer.close();
			BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));

			String line;
			while ((line = br.readLine()) != null) {
				jsonString.append(line);
			}
			br.close();
			connection.disconnect();
		} catch (Exception e) {
			//throw new RuntimeException(e.getMessage());
		}
		return jsonString.toString();
	}
}
