function initMap() {

	var dublin = {
		info : '<strong> Dublin Airport</strong><br>\
			    Dublin St<br> Ireland<br>\
					<a href="https://www.google.ie/maps/dir//Dublin+Airport+(DUB),+Dublin/@53.4264481,-6.2520985,17z/data=!4m15!1m6!3m5!1s0x486711be6993192f:0x55121bb5b725f355!2sDublin+Airport+(DUB)!8m2!3d53.4264481!4d-6.2499098!4m7!1m0!1m5!1m1!1s0x486711be6993192f:0x55121bb5b725f355!2m2!1d-6.2499098!2d53.4264481">Get Directions</a>',
		lat : 53.426448,
		long : -6.249910
	};

	var galway = {
		info : '<strong>Galway</strong><br>\
					Ireland<br>\
					<a href="https://www.google.ie/maps/dir//Galway+Airport,+Carnmore,+Galway/@53.3019146,-9.0104907,12z/data=!3m1!4b1!4m8!4m7!1m0!1m5!1m1!1s0x485b91bda96fc1cb:0x2522aa4d82c742f5!2m2!1d-8.9404507!2d53.3019351">Get Directions</a>',
		lat : 53.301935,
		long : -8.940451
	};

	var IsleofMan = {
		info : '<strong>Isle of Man</strong><br>\r\
					Isle of Man<br>\
					<a href="https://www.google.ie/maps/dir//Isle+of+Man+Airport,+United+Kingdom/@54.0865754,-4.7039798,12z/data=!3m1!4b1!4m9!4m8!1m0!1m5!1m1!1s0x48638c00820672ff:0xa72f32eb4f7e65a3!2m2!1d-4.6339398!2d54.0865957!3e4">Get Directions</a>',
		lat : 54.236107,
		long : -4.548055999999974
	};
	
	var Cork = {
			info : '<strong>Cork Airport</strong><br>\r\
						Cork, Ireland<br>\
						<a href="https://www.google.ie/maps/dir//Cork+Airport+(ORK),+Kinsale+Rd,+Cork/@51.8443651,-8.495785,18z/data=!4m15!1m6!3m5!1s0x48448fafbf85db05:0xa48d32b2615271d4!2sCork+Airport+(ORK)!8m2!3d51.8443701!4d-8.4946263!4m7!1m0!1m5!1m1!1s0x48448fafbf85db05:0xa48d32b2615271d4!2m2!1d-8.4946263!2d51.8443701">Get Directions</a>',
			lat : 51.8444,
			long : 8.4946
		};

	var locations = [ [ dublin.info, dublin.lat, dublin.long, 0 ],
			[ galway.info, galway.lat, galway.long, 1 ],
			[ IsleofMan.info, IsleofMan.lat, IsleofMan.long, 2 ],
			[ Cork.info, Cork.lat, Cork.long, 3 ]];

	var map = new google.maps.Map(document.getElementById('map'), {
		zoom : 13,
		center : new google.maps.LatLng(53.426448, -6.249910),
		mapTypeId : google.maps.MapTypeId.ROADMAP
	});

	var infowindow = new google.maps.InfoWindow({});

	var marker, i;

	for (i = 0; i < locations.length; i++) {
		marker = new google.maps.Marker(
				{
					position : new google.maps.LatLng(locations[i][1],
							locations[i][3]),
					map : map
				});

		google.maps.event.addListener(marker, 'click', (function(marker, i) {
			return function() {
				infowindow.setContent(locations[i][0]);
				infowindow.open(map, marker);
			}
		})(marker, i));
	}
}
