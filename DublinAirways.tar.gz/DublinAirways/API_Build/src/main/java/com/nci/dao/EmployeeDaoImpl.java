package com.nci.dao;

import java.util.List;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nci.bean.Employee;

@Repository("employeeDao")
public class EmployeeDaoImpl implements EmployeeDao {
	private JdbcTemplate jdbcTemplate;

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	// java class to perform the API web request and saving them to database

	public List<Employee> getEmployees() {
		List<Employee> employees = null;
		try {
			employees = jdbcTemplate.query("SELECT * FROM food", new BeanPropertyRowMapper<Employee>(Employee.class));
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
		return employees;
	}

	public Employee getEmployee(Long employeeId) {
		Employee employee = null;
		try {
			employee = jdbcTemplate.queryForObject("SELECT * FROM food WHERE food_id = ?", new Object[] { employeeId },
					new BeanPropertyRowMapper<Employee>(Employee.class));
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
		return employee;
	}

	public int deleteEmployee(Long employeeId) {
		int count = jdbcTemplate.update("DELETE from food WHERE food_id = ?", new Object[] { employeeId });
		return count;
	}

	public int updateEmployee(Employee employee) {
		int count = jdbcTemplate.update(
				"UPDATE food set food_type = ? , food_dish = ? , food_size = ? , food_quantity = ?, food_date = ?,food_time = ? where food_id = ?",
				new Object[] { employee.getFoodType(), employee.getFoodDish(), employee.getFoodSize(),
						employee.getFoodQuantity(), employee.getFoodDate(), employee.getFoodTime(),
						employee.getFoodId() });
		return count;
	}

	public int createEmployee(Employee employee) {
		int count = jdbcTemplate.update(
				"INSERT INTO food(food_id,food_type, food_dish, food_size,food_quantity,food_date,food_time)VALUES(?,?,?,?,?,?,?)",
				new Object[] { employee.getFoodId(), employee.getFoodType(), employee.getFoodDish(),
						employee.getFoodSize(), employee.getFoodQuantity(), employee.getFoodDate(),
						employee.getFoodTime() });
		return count;
	}
}