package com.nci.bean;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Employee {
	private Long foodId;
	private String foodType;
	private String foodDish;
	private String foodSize;
	private Long foodQuantity;

	// the bean class to set an get food instance variables
	private String foodDate;
	private String foodTime;

	@JsonCreator
	public Employee(@JsonProperty("foodId") Long foodId, @JsonProperty("foodType") String foodType,
			@JsonProperty("foodDish") String foodDish, @JsonProperty("foodQuantity") Long foodQuantity,
			@JsonProperty("foodSize") String foodSize, @JsonProperty("foodDate") String foodDate,
			@JsonProperty("foodTime") String foodTime) {
		this.foodId = foodId;
		this.foodType = foodType;
		this.foodDish = foodDish;

		this.foodQuantity = foodQuantity;

		this.foodSize = foodSize;
		this.foodDate = foodDate;
		this.foodTime = foodTime;
	}

	public Employee() {
	}

	public Long getFoodId() {
		return foodId;
	}

	public void setFoodId(Long foodId) {
		this.foodId = foodId;
	}

	public String getFoodType() {
		return foodType;
	}

	public void setFoodType(String foodType) {
		this.foodType = foodType;
	}

	public String getFoodDish() {
		return foodDish;
	}

	public void setFoodDish(String foodDish) {
		this.foodDish = foodDish;
	}

	public Long getFoodQuantity() {
		return foodQuantity;
	}

	public void setFoodQuantity(Long foodQuantity) {
		this.foodQuantity = foodQuantity;
	}

	public String getFoodSize() {
		return foodSize;
	}

	public void setFoodSize(String foodSize) {
		this.foodSize = foodSize;
	}

	public String getFoodDate() {
		return foodDate;
	}

	public void setFoodDate(String foodDate) {
		this.foodDate = foodDate;
	}

	public String getFoodTime() {
		return foodTime;
	}

	public void setFoodTime(String foodTime) {
		this.foodTime = foodTime;
	}

	
	// default string override to return a we;; formed json
	@Override
	public String toString() {
		StringBuilder str = new StringBuilder();
		str.append("Food Id:- " + getFoodId());
		str.append("Food Type:- " + getFoodType());
		str.append("Food Dish:- " + getFoodDish());
		str.append("Food Size:- " + getFoodSize());
		str.append("Food Quantity:- " + getFoodQuantity());
		str.append("Food Date:- " + getFoodDate());
		str.append("Food Time:- " + getFoodTime());
		return str.toString();
	}
}