package com.nci.dao;

import java.util.List;

import com.nci.bean.Employee;

public interface EmployeeDao {
	public List<Employee> getEmployees();
// the interface class which deals supplies data contracts for controller class
	public Employee getEmployee(Long employeeId);

	public int deleteEmployee(Long employeeId);

	public int updateEmployee(Employee employee);

	public int createEmployee(Employee employee);
}